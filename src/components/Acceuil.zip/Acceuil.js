import React, { Component } from 'react'
import './acceuil.css'
import axios from 'axios';
import { confirmAlert } from 'react-confirm-alert'; // Import
import 'react-confirm-alert/src/react-confirm-alert.css'; // Import css
// import Modal from './modal';
export default class Acceuil extends Component {
    constructor(props) {
        super(props);
  
        this.state = {
            profil: [],
            nom:"",
            prenom:"",
            email:"",
            telephone:""
        };
        this.handleChange = this.handleChange.bind(this);
  
    }
    componentDidMount() {
        
        axios.get("http://localhost:8080/atelier").then(res => {
           
            this.setState({ profil: res.data })
            console.log(this.state.profil)
  
        })
    }
    handleChange(e){
        this.setState({
            [e.target.name]: e.target.value
        })
    }
    render() {
      
        
        return (
            
              <div id="DD">
             <div id="desc">
           <img  src="chef.png"  id="chef"/> <br></br>
            <p>Retrouvez nos meilleurs recettes de cuisine </p>
           </div>
            <div id="descript">
           {this.state.profil.length>0 ?(this.state.profil.filter(pro=>pro.visibilite==true).map(prof=>{
            console.log(prof.image)
         var url="http://localhost:8080/public/"+prof.image
      return(
  <div id="atelier"> 
      <div id="imag"> <img src={url} id="larg"/></div>
      <div class=" cardbody card-body">
             <h2 class="card-title">{prof.titre}</h2>
             <p class="card-text">{prof.description}</p>
             <p class="card-text">{prof.date}</p>
             <p class="card-text">{prof.horaire}</p>
             <p class="card-text">{prof.placedispo}</p>
             <p class="card-text">{prof.placereserve}</p>
             <a href="#" >{prof.prix}</a><br></br>
             <button class=" inscr btn btn-primary" onClick={()=>{
                //  axios.post("http://localhost:8080/particulier/"+prof._id)
                confirmAlert({
                    customUI: ({ onClose }) => {
                      return (
                        <div className='custom-ui'>
                        <input  name="nom" onChange={ this.handleChange } placeholder="Entrer votre nom" value={this.state.value}/><br/>
                        <input name="prenom" onChange={ this.handleChange }  placeholder="Entrer votre prenom"v alue={this.state.value}/><br/>
                        <input name="email" onChange={ this.handleChange } placeholder="Entrer votre email" value={this.state.value}/><br/>
                         <input name="telephone" onChange={ this.handleChange } placeholder="Entrer votre numero telephone"/><br/>
                          <button onClick={onClose}>Fermer</button>
                          <button
                            onClick={() => {
                                axios.post("http://localhost:8080/particulier/"+prof._id,{
                                    nom:this.state.nom,
                                    prenom:this.state.prenom,
                                    email:this.state.email,
                                    telephone:this.state.telephone
                                }).then(res=>{
                                  axios.get("http://localhost:8080/atelier").then(res => {
           
            this.setState({ profil: res.data })
            console.log(this.state.profil)
  
        })
                                  console.log(res.data);
                                })
                              onClose();
                            }}
                          className="btn btn-success">
                          Participer
                          </button>
                        </div>
                      );
                    }
                  });
                 }} >S'inscrire</button>
  </div > 
      
     </div>
      )})):""} 
           </div>
           <div id="desc2">
             <p>Portfolio Sandy Arivelo</p>
           </div>

        <div className="fond"> 
            <img  src="cuisine1.jpg"  id="imgfond"/>
        </div>
    </div>
              
            
        )
    }
}
